from deepnet.deepnetclassfy import *

